from setuptools import setup, find_packages

setup(
    name='Hotel',
    version='1.1',
    packages=["Hotel", "Hotel.Person", "Hotel.Service"],
    license='MIT',
    description='A test python package',
	url='https://github.com/anqiubc/533-lab4',
    author=['Anqi Li','Evelyn Sugihermanto'],
    author_email='lianqi20209@gmail.com, evelynsugihermanto@yahoo.com'
)